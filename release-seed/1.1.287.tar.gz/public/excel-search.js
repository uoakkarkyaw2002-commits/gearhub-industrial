/* 1.1.215 owner: a search in a seller shop also shows the matching rows of the shop's Excel file under
   the products, from the "BC" sheet (the first sheet when there is no BC). Tapping a row, or "Open in
   Excel", opens the Excel viewer on that sheet with the same search. The workbook is read once per page
   (the offline copy from excel-library.js when there is no line). */
(()=>{
 const input=document.getElementById('search'),products=document.getElementById('products'),slug=(location.pathname.match(/^\/shops\/([^/]+)/)||[])[1];
 if(!input)return;
 // 1.1.221 owner: while something is typed the bar runs full width (scan and folder hide) and ends with
 // the number found, ˄ ˅ (Excel view) and a bin that clears the search.
 const pill=input.closest('.search-pill'),tools=document.createElement('span');tools.className='search-tools';
 tools.innerHTML='<span class="search-count" aria-live="polite"></span><button type="button" class="search-step" data-excel-step="-1" aria-label="Previous match"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="m6 15 6-6 6 6"/></svg></button><button type="button" class="search-step" data-excel-step="1" aria-label="Next match"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="m6 9 6 6 6-6"/></svg></button><button type="button" class="search-clear" aria-label="Clear search"><svg viewBox="0 0 24 24" aria-hidden="true"><rect class="bin-fill" x="7.6" y="8" width="8.8" height="12.4" rx="1"/><g class="bin-lid"><path d="M4 7h16M9 7V4.8h6V7"/></g><path d="M6.5 7l.9 12.2c.1 1 .9 1.8 1.9 1.8h5.4c1 0 1.8-.8 1.9-1.8L17.5 7M10 11v6M14 11v6"/></svg></button>';
 pill?.append(tools);
 const counter=tools.querySelector('.search-count'),steps=[...tools.querySelectorAll('.search-step')];
 const setCount=(text,nav)=>{counter.textContent=text||'';steps.forEach(b=>b.hidden=!nav)};setCount('',false);
 const clearNow=()=>{input.value='';input.dispatchEvent(new Event('input',{bubbles:true}));setCount('',false)};
 tools.querySelector('.search-clear').addEventListener('click',e=>eat(e.currentTarget));
 // 1.1.223 owner's video: the bin opens its lid, the typed letters jump into it one by one (first letter
 // first), the bin fills, the lid closes and a ring runs once around it; then the search is empty.
 // Same pace as the video (about 3 s).
 let eating=false;
 async function eat(bin){
  if(eating)return;const text=input.value;
  if(!text||matchMedia('(prefers-reduced-motion: reduce)').matches||!Element.prototype.animate){clearNow();input.focus();return}
  eating=true;input.readOnly=true;input.blur();
  const st=getComputedStyle(input),box=input.getBoundingClientRect(),layer=document.createElement('div');
  layer.className='bin-letters';layer.style.cssText='left:'+(box.left+parseFloat(st.paddingLeft)-input.scrollLeft)+'px;top:'+box.top+'px;height:'+box.height+'px;line-height:'+box.height+'px;font:'+st.font+';letter-spacing:'+st.letterSpacing+';color:'+st.color;
  layer.innerHTML=[...text].map(ch=>'<span>'+ch.replace(/[&<>]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;'})[c])+'</span>').join('');
  document.body.append(layer);input.classList.add('bin-hiding');
  const lid=bin.querySelector('.bin-lid'),fill=bin.querySelector('.bin-fill'),b=bin.getBoundingClientRect(),tx=b.left+b.width/2,ty=b.top+b.height*.42;
  const wait=ms=>new Promise(done=>setTimeout(done,ms));
  lid.animate([{transform:'rotate(0)'},{transform:'rotate(-38deg)'}],{duration:260,easing:'ease-out',fill:'forwards'});
  await wait(320);
  const spans=[...layer.children],gap=Math.min(120,1300/spans.length),fly=560;
  spans.forEach((span,i)=>{const r=span.getBoundingClientRect(),dx=tx-(r.left+r.width/2),dy=ty-(r.top+r.height/2);
   span.animate([{transform:'translate(0,0) rotate(0)',opacity:1},{transform:'translate('+dx*.55+'px,'+(dy-24)+'px) rotate(-18deg)',opacity:1,offset:.55},{transform:'translate('+dx+'px,'+dy+'px) scale(.25)',opacity:0}],{duration:fly,delay:i*gap,easing:'cubic-bezier(.3,.1,.6,1)',fill:'forwards'})});
  fill.animate([{transform:'scaleY(0)'},{transform:'scaleY(1)'}],{duration:Math.max(300,(spans.length-1)*gap+fly),delay:fly*.6,easing:'linear',fill:'forwards'});
  await wait((spans.length-1)*gap+fly+120);
  layer.remove();
  lid.animate([{transform:'rotate(-38deg)'},{transform:'rotate(0)'}],{duration:300,easing:'ease-in',fill:'forwards'});
  await wait(320);
  const ring=document.createElement('span');ring.className='bin-ring';ring.innerHTML='<svg viewBox="0 0 44 44" aria-hidden="true"><circle cx="22" cy="22" r="20"/></svg>';bin.append(ring);
  ring.querySelector('circle').animate([{strokeDashoffset:126},{strokeDashoffset:0}],{duration:760,easing:'ease-in-out',fill:'forwards'});
  await wait(820);
  ring.animate([{opacity:1},{opacity:0}],{duration:260,fill:'forwards'});fill.animate([{transform:'scaleY(1)'},{transform:'scaleY(0)'}],{duration:260,fill:'forwards'});
  await wait(280);
  ring.remove();lid.getAnimations().forEach(a=>a.cancel());fill.getAnimations().forEach(a=>a.cancel());
  input.classList.remove('bin-hiding');input.readOnly=false;eating=false;clearNow();
 }

 tools.addEventListener('click',e=>{const st=e.target.closest('[data-excel-step]');if(st)go(+st.dataset.excelStep)});
 if(!products||!slug)return;
 const SHEET='BC',LIMIT=200;
 const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'})[c]);
 const box=document.createElement('section');box.className='excel-results';box.hidden=true;box.setAttribute('aria-live','polite');
 box.innerHTML='<div class="excel-results-rows"></div><div class="excel-results-host" hidden></div>';
 const rowsArea=box.firstChild,host=box.lastChild;
 products.after(box);
 let loading=null,refreshing=null,signature=null,checkedAt=0,timer=0,turn=0;
 // Revalidate immutable file IDs, while keeping parsed data during offline/failed requests.
 function workbook(force=false){
  if(loading&&(!force&&Date.now()-checkedAt<30000||navigator.onLine===false))return loading;
  if(refreshing)return refreshing;
  refreshing=(async()=>{
   try{
    const viewer=window.GearHubExcelViewer;if(!viewer)return null;
    const response=await fetch('/api/platform/store/'+encodeURIComponent(slug)+'/spreadsheets',{cache:'no-store',signal:AbortSignal.timeout(8000)});
    if(!response.ok)throw Error('Could not refresh Excel files.');
    const files=((await response.json()).files||[]).filter(f=>/\.xls[xm]$/i.test(f.name)),next=files.map(f=>f.url).join('|');checkedAt=Date.now();
    if(loading&&signature===next)return await loading;
    const previous=loading;signature=next;
    loading=(async()=>{let first=null;
     for(const file of files){const sheet=await viewer.sheet(file.url,SHEET);if(!sheet)continue;const index=await window.GearHubExcelIndex.forSheet(sheet),found={file,sheet,index};if(sheet.name.trim().toLowerCase()===SHEET.toLowerCase())return found;first=first||found}
     return first;
    })();
    try{const result=await loading;previous?.then(found=>found?.index.dispose());return result}catch(error){loading=previous;signature=null;throw error}
   }catch{checkedAt=Date.now();return loading?await loading.catch(()=>null):null}finally{refreshing=null}
  })();return refreshing;
 }
 window.GearHubExcelSearchIdle=()=>Promise.allSettled([refreshing,loading]);
 // 1.1.217: two views — only the matching rows ("ရှာတာပဲ"), or the sheet like Excel ("Excel လို").
 // 1.1.224 owner: the Excel view is the shop's real Excel viewer under the search bar — original column
 // and row sizes, drag-select, copy, row select — moved to the bar's ˄ ˅ and count.
 const MODE_KEY='gh-excel-search-mode';let mode=(()=>{try{return localStorage.getItem(MODE_KEY)==='sheet'?'sheet':'rows'}catch{return 'rows'}})();
 function hideAll(){box.hidden=true;rowsArea.innerHTML='';host.hidden=true;full(false);setCount('',false);window.GearHubExcelViewer?.release()}
 const countSheet=s=>setCount(s.total?(s.at+1)+'/'+s.total:'0',s.total>1);
 async function show(){
  const q=input.value.trim(),mine=++turn;
  if(q.length<2){hideAll();return}
  const found=await workbook();if(mine!==turn)return;
  if(!found){hideAll();return}
  const {file,sheet,index}=found,viewer=window.GearHubExcelViewer;
  box.hidden=false;full(mode==='sheet');
  if(mode==='sheet'){
   rowsArea.innerHTML='';host.hidden=false;fit();
   if(!await viewer.embed(host,file.url,file.name,sheet.name,null)||mine!==turn)return;
   countSheet(viewer.search(q));return;
  }
  // 1.1.225 owner: "ရှာတာပဲ" is the same Excel viewer showing only the header and the matching rows —
  // select, drag, copy and row select work right here; nothing opens the full viewer.
  const head=index.head,hits=await index.search(q);if(mine!==turn)return;
  setCount(String(hits.length)+(hits.length>=LIMIT?'+':''),false);
  if(!hits.length){viewer.release();host.hidden=true;rowsArea.innerHTML='<p class="excel-results-none">Excel · '+esc(sheet.name)+' — No match</p>';return}
  rowsArea.innerHTML='';host.hidden=false;
  host.style.height=Math.round(window.innerHeight*.75)+'px';
  if(!await viewer.embed(host,file.url,file.name,sheet.name,new Set([head,...hits]))||mine!==turn)return;
  viewer.search(q);
  // Fit the box to the drawn rows (up to three quarters of the screen; the sheet scrolls past that).
  await new Promise(done=>requestAnimationFrame(()=>requestAnimationFrame(done)));if(mine!==turn)return;
  const g=host.querySelector('#excel-grid'),t=g?.querySelector('table');if(t){g.scrollTop=0;host.style.height=Math.min(window.innerHeight*.75,t.offsetHeight+2)+'px'}
 }
 // The Excel view hides the products and fills the screen under the search bar.
 function full(on){document.body.classList.toggle('excel-sheet-mode',on)}
 function fit(){
  const bar=document.querySelector('.mobile-search');window.scrollTo(0,bar&&getComputedStyle(bar).position!=='sticky'?bar.getBoundingClientRect().top+window.scrollY-8:0);
  const nav=document.querySelector('.mobile-bottom-nav'),below=nav&&getComputedStyle(nav).display!=='none'?nav.offsetHeight:0;
  host.style.height=Math.max(320,window.innerHeight-host.getBoundingClientRect().top-below)+'px';
 }
 addEventListener('resize',()=>{if(mode==='sheet'&&!box.hidden)fit()});
 function go(step){if(mode!=='sheet'||box.hidden)return;const v=window.GearHubExcelViewer;if(v)countSheet(v.step(step))}
 // The view choice, in the Excel files panel beside the search bar.
 const help=document.querySelector('.excel-library-help');
 if(help){const pick=document.createElement('div');pick.className='excel-search-setting';
  const paint=()=>{pick.innerHTML='<span>ရှာရင် Excel ပြပုံ / Search shows</span><div class="excel-results-modes" role="group" aria-label="Search view"><button type="button" data-excel-mode="rows" aria-pressed="'+(mode==='rows')+'">ရှာတာပဲ</button><button type="button" data-excel-mode="sheet" aria-pressed="'+(mode==='sheet')+'">Excel လို</button></div>'};
  paint();help.after(pick);
  pick.addEventListener('click',e=>{const m=e.target.closest('[data-excel-mode]');if(!m)return;mode=m.dataset.excelMode;try{localStorage.setItem(MODE_KEY,mode)}catch{}paint();if(input.value.trim())show()});
 }
 input.addEventListener('input',()=>{++turn;clearTimeout(timer);if(input.value.trim().length<2)hideAll();timer=setTimeout(show,150)});
 const refresh=async()=>{if(!loading&&input.value.trim().length<2)return;const previous=loading;await workbook(true);if(loading!==previous&&input.value.trim().length>=2)show()};
 setInterval(()=>{if(!document.hidden&&navigator.onLine!==false&&input.value.trim().length>=2)refresh()},30000);
 addEventListener('gearhub-excel-changed',async()=>{await refreshing;checkedAt=0;await refresh()});addEventListener('online',refresh);addEventListener('focus',refresh);
 document.addEventListener('visibilitychange',()=>{if(!document.hidden)refresh()});
 // The keyboard's Search key: next match in the Excel view, then the keyboard closes so the sheet shows.
 input.addEventListener('keydown',e=>{if(e.key!=='Enter')return;e.preventDefault();if(mode==='sheet'&&!box.hidden)go(1);input.blur()});
 // Speed (1.1.224): the shop's workbook is read in the background once the page is idle, so the first
 // search answers at once. Skipped when the phone asks to save data.
 if(!navigator.connection?.saveData)(window.requestIdleCallback||(f=>setTimeout(f,2500)))(()=>workbook(),{timeout:6000});
 if(input.value.trim())show();
})();
